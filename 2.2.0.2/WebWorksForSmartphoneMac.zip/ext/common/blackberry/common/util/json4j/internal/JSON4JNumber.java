/*
 * PhoneGap is available under *either* the terms of the modified BSD license *or* the
 * MIT License (2008). See http://www.phonegap.com/about/license/ for full text.
 *
 * Copyright (c) 2011, IBM Corporation
 */

package blackberry.common.util.json4j.internal;

public class JSON4JNumber {
}
